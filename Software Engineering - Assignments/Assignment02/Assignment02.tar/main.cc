#include <iostream>
#include <string>
using namespace std;

#include "defs.h"
#include "Control.h"


int main()
{
    Control myControl;
    myControl.launch();
}