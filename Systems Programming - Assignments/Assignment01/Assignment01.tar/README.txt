Program author:
Deneo Shi 101271921

Purpose:
Displays and runs a game (random generated): Dragon's Hollow. Timmy and Harold (T and H) will move (randomly) and the outcomes will be randomly determined depnending of the birds' randomly generated outcomes.

Compilation and Launching Instructions:
gcc -Wall -o a1 a1.c
./a1

